const weatherDataEl = document.getElementById("weatherData");
const aqiDataEl = document.getElementById("aqiData");
const healthTipEl = document.getElementById("healthTip");
const refreshBtn = document.getElementById("refreshBtn");
const cityInput = document.getElementById("cityInput");
const countryInput = document.getElementById("countryInput");
const searchBtn = document.getElementById("searchBtn");
const locationLabel = document.getElementById("locationLabel");
const statusMessageEl = document.getElementById("statusMessage");

let currentLocation = {
  city: DEFAULT_CITY,
  country: DEFAULT_COUNTRY
};

function setStatus(message, isError = false) {
  statusMessageEl.textContent = message;
  statusMessageEl.classList.toggle("error", isError);
}

function sanitizeLocation(value) {
  return value.trim();
}

function getLocationQuery(cityValue, countryValue) {
  const city = sanitizeLocation(cityValue) || DEFAULT_CITY;
  const country = sanitizeLocation(countryValue);
  return { city, country };
}

async function fetchWeather(city, country) {
  if (!API_KEY) {
    throw new Error("OpenWeather API key is missing. Update config.js before deploying.");
  }

  const cityQuery = encodeURIComponent(city);
  const countryQuery = country ? `,${encodeURIComponent(country)}` : "";
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityQuery}${countryQuery}&appid=${API_KEY}&units=${DEFAULT_UNITS}`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error("Weather data could not be loaded for this location.");
  }

  return res.json();
}

async function fetchAQI(city, country) {
  if (!API_KEY) {
    throw new Error("OpenWeather API key is missing. Update config.js before deploying.");
  }

  const geoUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(city)}${country ? `,${encodeURIComponent(country)}` : ""}&limit=1&appid=${API_KEY}`;
  const geoRes = await fetch(geoUrl);

  if (!geoRes.ok) {
    throw new Error("Location lookup failed.");
  }

  const geoData = await geoRes.json();
  if (!geoData || geoData.length === 0) {
    throw new Error("City not found. Try another location.");
  }

  const { lat, lon } = geoData[0];
  const aqiUrl = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`;
  const aqiRes = await fetch(aqiUrl);

  if (!aqiRes.ok) {
    throw new Error("AQI data could not be loaded.");
  }

  return aqiRes.json();
}

function getHealthTip(aqiValue) {
  if (aqiValue <= 50) {
    return "Air quality is good. Ideal for outdoor activities.";
  }
  if (aqiValue <= 100) {
    return "Air quality is moderate. Sensitive individuals should limit prolonged outdoor exertion.";
  }
  if (aqiValue <= 150) {
    return "Unhealthy for sensitive groups. People with respiratory issues should reduce outdoor activity.";
  }
  if (aqiValue <= 200) {
    return "Unhealthy air quality. Everyone should reduce prolonged outdoor exertion.";
  }
  return "Very unhealthy air quality. Avoid outdoor activities if possible.";
}

function renderWeather(weather) {
  const temp = weather.main.temp;
  const feels = weather.main.feels_like;
  const desc = weather.weather[0].description;
  const humidity = weather.main.humidity;
  const wind = weather.wind?.speed ?? 0;

  weatherDataEl.innerHTML = `
    <p><strong>Temperature:</strong> ${temp.toFixed(1)} °C (feels like ${feels.toFixed(1)} °C)</p>
    <p><strong>Condition:</strong> ${desc}</p>
    <p><strong>Humidity:</strong> ${humidity}%</p>
    <p><strong>Wind Speed:</strong> ${wind.toFixed(1)} m/s</p>
  `;
}

function renderAQI(aqiData) {
  const aqiValue = aqiData.list[0].main.aqi;

  const aqiDisplayMap = {
    1: 30,
    2: 60,
    3: 120,
    4: 180,
    5: 250
  };

  const approxAQI = aqiDisplayMap[aqiValue] || 100;

  aqiDataEl.innerHTML = `
    <p><strong>AQI Category (scaled):</strong> ${aqiValue} / 5</p>
    <p><strong>Approx. US AQI:</strong> ${approxAQI}</p>
  `;

  healthTipEl.textContent = getHealthTip(approxAQI);
}

async function updateDashboard(cityValue = currentLocation.city, countryValue = currentLocation.country) {
  const selectedLocation = getLocationQuery(cityValue, countryValue);
  currentLocation = selectedLocation;

  cityInput.value = selectedLocation.city;
  countryInput.value = selectedLocation.country;
  weatherDataEl.textContent = "Loading weather...";
  aqiDataEl.textContent = "Loading AQI...";
  healthTipEl.textContent = "";
  setStatus("Fetching latest weather details...");

  try {
    const [weather, aqi] = await Promise.all([
      fetchWeather(selectedLocation.city, selectedLocation.country),
      fetchAQI(selectedLocation.city, selectedLocation.country)
    ]);

    locationLabel.textContent = `${weather.name}, ${weather.sys?.country || selectedLocation.country.toUpperCase() || "Current location"}`;
    renderWeather(weather);
    renderAQI(aqi);
    setStatus(`Updated for ${weather.name}.`);
  } catch (error) {
    console.error(error);
    weatherDataEl.textContent = "Failed to load weather.";
    aqiDataEl.textContent = "Failed to load AQI.";
    healthTipEl.textContent = "";
    setStatus(error.message || "Unable to load weather data.", true);
  }
}

function handleSearch(event) {
  event.preventDefault();
  const requestedLocation = getLocationQuery(cityInput.value, countryInput.value);

  if (!requestedLocation.city) {
    setStatus("Please enter a city name.", true);
    return;
  }

  updateDashboard(requestedLocation.city, requestedLocation.country);
}

searchBtn.addEventListener("click", handleSearch);
cityInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    handleSearch(event);
  }
});
countryInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    handleSearch(event);
  }
});
refreshBtn.addEventListener("click", () => updateDashboard(currentLocation.city, currentLocation.country));

cityInput.value = DEFAULT_CITY;
countryInput.value = DEFAULT_COUNTRY;
updateDashboard(DEFAULT_CITY, DEFAULT_COUNTRY);
setInterval(() => updateDashboard(currentLocation.city, currentLocation.country), 2 * 60 * 1000);