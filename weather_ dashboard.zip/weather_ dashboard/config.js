window.WEATHER_CONFIG = {
  API_KEY: "e0864d0c140aee6ed105598ab3e9e450",
  DEFAULT_CITY: "Bengaluru",
  DEFAULT_COUNTRY: "IN",
  UNITS: "metric"
};

const API_KEY = window.WEATHER_CONFIG.API_KEY || "";
const DEFAULT_CITY = window.WEATHER_CONFIG.DEFAULT_CITY || "Bengaluru";
const DEFAULT_COUNTRY = window.WEATHER_CONFIG.DEFAULT_COUNTRY || "";
const DEFAULT_UNITS = window.WEATHER_CONFIG.UNITS || "metric";